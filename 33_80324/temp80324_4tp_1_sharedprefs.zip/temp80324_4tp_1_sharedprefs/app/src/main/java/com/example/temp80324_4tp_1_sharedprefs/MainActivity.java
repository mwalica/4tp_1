package com.example.temp80324_4tp_1_sharedprefs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.chip.Chip;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public static final String SHARED_PREF_1 = "shared_prefs_1";
    public static final String RANDOM_NUM = "num";
    private Button btnRandomNum;
    private Chip chipResult;
    private int randomNum;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRandomNum = findViewById(R.id.btnRandomNum);
        chipResult = findViewById(R.id.chipResult);
        sharedPreferences = getSharedPreferences(SHARED_PREF_1, MODE_PRIVATE);
        loadPrefs();
        setVisibility();

        btnRandomNum.setOnClickListener(view -> {
            randomNum = new Random().nextInt(100) + 1;
            setVisibility();
            savePrefs();
        });

        chipResult.setOnCloseIconClickListener(view -> {
            sharedPreferences.edit().clear().apply();
            randomNum = 0;
            setVisibility();
        });
    }

    private void setVisibility() {
        if (randomNum > 0) {
            chipResult.setText(String.valueOf(randomNum));
            chipResult.setVisibility(View.VISIBLE);
        } else {
            chipResult.setVisibility(View.INVISIBLE);
        }
    }

    private void savePrefs() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(RANDOM_NUM, randomNum);
        editor.apply();
    }

    private void loadPrefs() {
        randomNum = sharedPreferences.getInt(RANDOM_NUM, 0);
    }
}