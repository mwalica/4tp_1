package com.example.temp70324_4tp_1_camera_gallery;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class GalleryActivity extends AppCompatActivity {
    private Button btnGallery;
    private ImageView ivGalleryPhoto;
    private ActivityResultLauncher<String> resultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        btnGallery = findViewById(R.id.btnGallery);
        ivGalleryPhoto = findViewById(R.id.ivGalleryPhoto);

        resultLauncher = registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri uri) {
                ivGalleryPhoto.setImageURI(uri);
            }
        });

        btnGallery.setOnClickListener(view -> {
            resultLauncher.launch("image/*");
        });
    }
}