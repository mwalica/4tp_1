package com.example.temp140324_4tp1_spinner_snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private Button btnSave;
    private View view1, view2;
    private String selectedColor = "";
    private String[] colors = {"yellow", "grey", "purple"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        btnSave = findViewById(R.id.btnSave);
        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, colors);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
//                selectedColor =  (String) adapterView.getSelectedItem();
                selectedColor = colors[position];
                view1.setBackgroundColor(Color.parseColor(selectedColor));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnSave.setOnClickListener(view -> {
            view2.setBackgroundColor(Color.parseColor(selectedColor));
            Snackbar.make(view1, "To jest sanckbar", Snackbar.LENGTH_LONG)
                    .setAction("OK", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Toast.makeText(MainActivity.this, "Snakbar ok", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setAnimationMode(Snackbar.ANIMATION_MODE_SLIDE)
                    .setAnchorView(view1)
                    .show();
        });
    }
}