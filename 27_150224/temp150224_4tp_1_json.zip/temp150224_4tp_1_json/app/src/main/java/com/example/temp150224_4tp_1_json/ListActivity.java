package com.example.temp150224_4tp_1_json;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Person> persons = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        recyclerView = findViewById(R.id.recyclerView);

        try {
            JSONArray personsJSON = new JSONArray(loadJsonFromAssets());

            for(int i = 0; i < personsJSON.length(); i++) {
                JSONObject personObj = personsJSON.getJSONObject(i);
                String firstName = personObj.getString("firstName");
                String city = personObj.getJSONObject("address").getString("city");
                persons.add(new Person(firstName, city));
            }
            Log.d("my_log", "persons: " + persons.size());
        } catch(JSONException e) {
            Toast.makeText(ListActivity.this, "Błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        PersonsAdapter adapter = new PersonsAdapter(persons);
        recyclerView.setAdapter(adapter);
    }

    private String loadJsonFromAssets() {
        String json = null;
        try {
            InputStream inputStream = getAssets().open("persons.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            json = new String(buffer, "UTF-8");
        } catch (IOException error) {
            Toast.makeText(this, "Error: " + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            return "";
        }

        return json;
    }
}