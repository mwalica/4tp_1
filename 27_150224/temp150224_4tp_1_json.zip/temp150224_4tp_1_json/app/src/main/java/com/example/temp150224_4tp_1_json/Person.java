package com.example.temp150224_4tp_1_json;

public class Person {
    private String firstName;
    private String city;

    public Person(String firstName, String city) {
        this.firstName = firstName;
        this.city = city;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getCity() {
        return city;
    }
}
