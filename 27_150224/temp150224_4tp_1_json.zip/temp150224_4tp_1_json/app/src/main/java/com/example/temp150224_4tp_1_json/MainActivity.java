package com.example.temp150224_4tp_1_json;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    public static final String JSON = "{\n" +
            "  \"firstName\": \"Jan\",\n" +
            "  \"age\": 24\n" +
            "}";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnShow = findViewById(R.id.btnShow);
        TextView tvResult = findViewById(R.id.tvResult);
        ConstraintLayout constraintLayout = findViewById(R.id.constrainLayout);

        constraintLayout.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            startActivity(intent);
        });

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    JSONObject person = new JSONObject(loadJsonFromAssets());
                    String firstName = person.getString("firstName");
                    int age = person.getInt("age");
                    JSONObject address = person.getJSONObject("address");
                    String city = address.getString("city");
                    String country = address.getString("country");
                    JSONArray hobbies = person.getJSONArray("hobbies");
                    String str = "";
                    for (int i = 0; i < hobbies.length(); i++) {
                        if (i != hobbies.length() - 1) {
                            str += hobbies.get(i) + ", ";
                        } else {
                            str += hobbies.get(i);
                        }
                    }

                    String msg = firstName + ", " + age + " lat\n" + country + ", " + city + "\n" + str;
                    tvResult.setText(msg);

                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this, "Błąd: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private String loadJsonFromAssets() {
        String json = null;
        try {
            InputStream inputStream = getAssets().open("person.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            json = new String(buffer, "UTF-8");
        } catch (IOException error) {
            Toast.makeText(this, "Error: " + error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            return "";
        }

        return json;
    }
}