package com.example.temp71223_4tp_1_handler_runnable;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult1, tvResult2;
    private Button btnStop;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);
        btnStop = findViewById(R.id.btnStop);

        Runnable runnable1 = new Runnable() {
            @Override
            public void run() {
                tvResult1.setText("Tekst pojawia się po 2 sekundach");
            }
        };

        Runnable runnable2 = new Runnable() {
            @Override
            public void run() {
                tvResult1.setText("");
            }
        };

        Runnable runnable3 = new Runnable() {
            @Override
            public void run() {
                tvResult2.append("hello ");
                handler.postDelayed(this, 1000);
            }
        };

        runnable3.run();
        handler.postDelayed(runnable1, 2000);
        handler.postDelayed(runnable2, 4000);

        btnStop.setOnClickListener(view -> {
            handler.removeCallbacks(runnable3);
        });

    }
}