package com.example.temp131023_4tp1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView tvColor1, tvColor2;
    private ConstraintLayout constraintLayout;
    private Spinner spinner;
    private Button btnRead;

    public MainActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvColor1 = findViewById(R.id.tvColor1);
        tvColor2 = findViewById(R.id.tvColor2);
        constraintLayout = findViewById(R.id.constrainLayout);
        spinner = findViewById(R.id.spinner);
        btnRead = findViewById(R.id.btnRead);

        tvColor1.setOnClickListener(this);
        tvColor2.setOnClickListener(this);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String color = (String) adapterView.getSelectedItem();
                tvColor2.setText(color);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String color = String.valueOf(spinner.getSelectedItem());
                tvColor1.setText(color);
            }
        });
    }

    @Override
    public void onClick(View view) {
        ColorDrawable background = (ColorDrawable) view.getBackground();
        int color = background.getColor();
        constraintLayout.setBackgroundColor(color);
    }
}