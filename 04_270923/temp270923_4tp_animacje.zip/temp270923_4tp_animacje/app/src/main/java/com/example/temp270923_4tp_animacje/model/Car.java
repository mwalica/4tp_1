package com.example.temp270923_4tp_animacje.model;

import java.io.Serializable;

public class Car implements Serializable {
    private String carName;
    private boolean isNew;

    public Car(String carName, boolean isNew) {
        this.carName = carName;
        this.isNew = isNew;
    }

    public String getCarName() {
        return carName;
    }

    public boolean isNew() {
        return isNew;
    }
}
