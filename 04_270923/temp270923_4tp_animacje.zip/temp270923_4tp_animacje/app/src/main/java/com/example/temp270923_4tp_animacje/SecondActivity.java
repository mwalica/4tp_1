package com.example.temp270923_4tp_animacje;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.temp270923_4tp_animacje.model.Car;

public class SecondActivity extends AppCompatActivity {

    private TextView tvCarName, tvCarState;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvCarName = findViewById(R.id.tvCarName);
        tvCarState = findViewById(R.id.tvCarState);
        btnBack = findViewById(R.id.btnBack);

//        if(getIntent().hasExtra(MainActivity.CAR_NAME_KEY) && getIntent().hasExtra(MainActivity.CAR_STATUS_KEY)) {
//            String carName = getIntent().getStringExtra(MainActivity.CAR_NAME_KEY);
//            boolean isNew = getIntent().getBooleanExtra(MainActivity.CAR_STATUS_KEY, true);
//
//            tvCarName.setText(carName);
//            tvCarState.setText(isNew ? "Stan: nowy" : "Stan: używany");
//        }
        if(getIntent().hasExtra(MainActivity.CAR_KEY)) {
           Car car = (Car) getIntent().getSerializableExtra(MainActivity.CAR_KEY);

            tvCarName.setText(car.getCarName());
            tvCarState.setText(car.isNew() ? "Stan: nowy" : "Stan: używany");
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    //strzałka nawigacyjne na appbar

    @Override
    public boolean onSupportNavigateUp() {
        super.onSupportNavigateUp();
        overridePendingTransition(R.anim.from_bottom, R.anim.to_top);
        return true;
    }

    //strzałka na dole <

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.from_bottom, R.anim.to_top);
    }
}