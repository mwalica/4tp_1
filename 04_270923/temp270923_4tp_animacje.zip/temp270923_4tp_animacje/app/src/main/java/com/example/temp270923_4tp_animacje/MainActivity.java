package com.example.temp270923_4tp_animacje;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.temp270923_4tp_animacje.model.Car;

public class MainActivity extends AppCompatActivity {

    public static final String CAR_NAME_KEY = "car";
    public static final String CAR_STATUS_KEY = "car_status";
    public static final String CAR_KEY = "car_obj";

    private EditText etCarName;
    private CheckBox cbState;
    private Button btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etCarName = findViewById(R.id.etCarName);
        cbState = findViewById(R.id.cbState);
        btnSend = findViewById(R.id.btnSend);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String carName = etCarName.getText().toString().trim();
                boolean isNew = cbState.isChecked();
                if (!carName.isEmpty()) {
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    //dołączenie informacji do intencji
//                    intent.putExtra(CAR_NAME_KEY, carName);
//                    intent.putExtra(CAR_STATUS_KEY, isNew);
                    Car car = new Car(carName, isNew);
                    intent.putExtra(CAR_KEY, car);
                    startActivity(intent);
//                    overridePendingTransition(R.anim.from_top, R.anim.to_bottom);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                } else {
                    Toast.makeText(MainActivity.this, "Prosze wpisać nazwę auta", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}