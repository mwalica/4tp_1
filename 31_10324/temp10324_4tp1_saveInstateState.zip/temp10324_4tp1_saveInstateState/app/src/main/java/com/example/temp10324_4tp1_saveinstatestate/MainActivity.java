package com.example.temp10324_4tp1_saveinstatestate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton floatingActionButton, floatingActionButton2;
    private TextView tvCounter;
//    private int count = 0;
    private MainViewModel viewModel;
    private SecondViewModel secondViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton2 = findViewById(R.id.floatingActionButton2);
        tvCounter = findViewById(R.id.tvCounter);

        //tworzymy obiekt MainViewModel
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);
        secondViewModel = new ViewModelProvider(this).get(SecondViewModel.class);

//        if(savedInstanceState != null) {
//            count = savedInstanceState.getInt("count_key");
//        }

//        tvCounter.setText(String.valueOf(viewModel.getCount()));

        secondViewModel.getCount().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(Integer counter) {
                tvCounter.setText(String.valueOf(counter));
            }
        });

        floatingActionButton.setOnClickListener(view -> {
//            viewModel.add();
            secondViewModel.add();
//            tvCounter.setText(String.valueOf(viewModel.getCount()));
        });

        floatingActionButton2.setOnClickListener(view -> {
//            viewModel.sub();
            secondViewModel.sub();
//            tvCounter.setText(String.valueOf(viewModel.getCount()));
        });
    }

//    @Override
//    protected void onSaveInstanceState(@NonNull Bundle outState) {
//        super.onSaveInstanceState(outState);
//        outState.putInt("count_key", count);
//    }
}