package com.example.temp10324_4tp1_saveinstatestate;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SecondViewModel extends ViewModel {
    private MutableLiveData<Integer> count = new MutableLiveData<>(0);

    public LiveData<Integer> getCount() {
        return count;
    }

    public void add() {
        if(count.getValue() != null) {
            count.setValue(count.getValue() + 1);
        }

    }

    public void sub() {
        if(count.getValue() != null) {
            count.setValue(count.getValue() - 1);
        }
    }
}
