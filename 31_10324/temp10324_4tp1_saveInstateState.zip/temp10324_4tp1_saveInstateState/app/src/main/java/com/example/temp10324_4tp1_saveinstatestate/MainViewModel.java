package com.example.temp10324_4tp1_saveinstatestate;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {

    private int count = 0;

    public int getCount() {
        return count;
    }


    public void add() {
        count++;
    }

    public void sub() {
        count--;
    }
}
