package com.example.temp230224_4tp_1_retrofit.model;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

public class Post {
    private int id;
    private String title;
    @SerializedName("body")
    private String description;

    public Post(int id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    @NonNull
    @Override
    public String toString() {
        return title;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }
}
