package com.example.temp151223_4tp1_sqlite.adapter;

import android.view.View;

public interface OnNoteClickListener {
    void onNoteClick(int position, View view);
}
