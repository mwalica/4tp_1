package com.example.temp110124_activity_for_result_4tp_1;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String NUM_KEY = "number";
    private Button btnSend;
    private ActivityResultLauncher<Integer> launcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSend = findViewById(R.id.btnSend);
        launcher = registerForActivityResult(new ActivityResultContract<Integer, Double>() {
            @Override
            public Double parseResult(int resultCode, @Nullable Intent intent) {
                if(resultCode == RESULT_OK) {
                    return intent.getDoubleExtra(SecondActivity.DOUBLE_KEY, 0.0);
                }
                return 0.0;
            }

            @NonNull
            @Override
            public Intent createIntent(@NonNull Context context, Integer integer) {
                return new Intent(MainActivity.this, SecondActivity.class).putExtra(MainActivity.NUM_KEY, integer);
            }
        }, result -> {
            Toast.makeText(this, "Odpowiedź: " + result, Toast.LENGTH_SHORT).show();
        });


        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launcher.launch(343);
            }
        });

    }
}