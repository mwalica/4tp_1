package com.example.temp110124_activity_for_result_4tp_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    public static final String DOUBLE_KEY = "double_num";

    private Button btnToMain;
    private TextView tvResult;
    private int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        btnToMain = findViewById(R.id.btnToMain);
        tvResult = findViewById(R.id.tvResult);

        if(getIntent().hasExtra(MainActivity.NUM_KEY)) {
            num = getIntent().getIntExtra(MainActivity.NUM_KEY, 0);
            tvResult.setText(num + "");
        }

        btnToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent().putExtra(DOUBLE_KEY, num * 1.5);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}