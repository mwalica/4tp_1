package com.example.temp91123_4tp1_shared_prefs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String SHARED_PREFS_1 = "shared_1";
    public static final String NAME_KEY = "name";
    public static final String SWITCH_STATE_KEY = "switch_state";

    private EditText etName;
    private TextView tvResult;
    private Button btnSave;
    private Switch mySwitch;
    private LinearLayout linearLayout;

    private String enteredName = "";
    private boolean switchState;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        tvResult = findViewById(R.id.tvResult);
        btnSave = findViewById(R.id.btnSave);
        mySwitch = findViewById(R.id.mySwitch);
        linearLayout = findViewById(R.id.linearLayout);

        sharedPreferences = getSharedPreferences(SHARED_PREFS_1, MODE_PRIVATE);
        loadSettings();
        upgradeScreen();


        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                enteredName = charSequence.toString();
                tvResult.setText(enteredName);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveSettings();
            }
        });

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                switchState = isChecked;
                if(switchState) {
                    linearLayout.setBackgroundColor(Color.LTGRAY);
                } else {
                    linearLayout.setBackgroundColor(Color.WHITE);
                }
            }
        });
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(NAME_KEY,enteredName);
        editor.putBoolean(SWITCH_STATE_KEY, switchState);
        editor.apply();
        Toast.makeText(this, "Ustawienia zapisane", Toast.LENGTH_SHORT).show();
    }

    private void loadSettings() {
        enteredName = sharedPreferences.getString(NAME_KEY, "");
        switchState = sharedPreferences.getBoolean(SWITCH_STATE_KEY, false);
    }

    private void upgradeScreen() {
        tvResult.setText(enteredName);
        mySwitch.setChecked(switchState);
        if(switchState) {
            linearLayout.setBackgroundColor(Color.LTGRAY);
        } else {
            linearLayout.setBackgroundColor(Color.WHITE);
        }

    }
}