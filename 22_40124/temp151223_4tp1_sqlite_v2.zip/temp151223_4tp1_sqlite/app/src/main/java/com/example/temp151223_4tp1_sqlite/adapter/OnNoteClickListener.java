package com.example.temp151223_4tp1_sqlite.adapter;

public interface OnNoteClickListener {
    void onNoteClick(int position);
}
