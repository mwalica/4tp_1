package com.example.temp151223_4tp1_sqlite.model;

import java.time.Instant;

public class Note {
    private int id;
    private String title;
    private String description;
    private long createdDate;

    public Note(String title, String description) {
        this.id = -1;
        this.title = title;
        this.description = description;
        this.createdDate = Instant.now().getEpochSecond();
    }

    public Note(int id, String title, String description, long createdDate) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.createdDate = createdDate;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public long getCreatedDate() {
        return createdDate;
    }
}
