package com.example.temp151223_4tp1_sqlite.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.temp151223_4tp1_sqlite.model.Note;

import java.io.DataOutputStream;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "notes_db_2";
    public static final int DB_VERSION = 1;
    private Context context;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, created_date INTEGER)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String sql = "DROP TABLE IF EXISTS notes";
        db.execSQL(sql);
        this.onCreate(db);
    }

    public void addNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", note.getTitle());
        cv.put("description", note.getDescription());
        cv.put("created_date", note.getCreatedDate());
        long result = db.insert("notes", null, cv);
        if(result == -1) {
            Toast.makeText(context, "Błąd podczas dodawania notatki", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Notatka dodana do bazy danych", Toast.LENGTH_SHORT).show();
        }
    }

    public Cursor getNotes() {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM notes";
        Cursor cursor = null;
        if( db != null) {
            cursor = db.rawQuery(sql, null);
        }
        return cursor;
    }

    public void deleteNote(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("notes", "id=?", new String[]{String.valueOf(id)});
        if(result == -1) {
            Toast.makeText(context, "Błąd podczas usuwania notatki", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Notatka zostałą usunięta z bazy danych", Toast.LENGTH_SHORT).show();
        }
    }
}
