package com.example.temp151223_4tp1_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.temp151223_4tp1_sqlite.database.DatabaseHelper;
import com.example.temp151223_4tp1_sqlite.model.Note;

public class AddActivity extends AppCompatActivity {

    private EditText etTitle, etDescription;
    private Button btnAdd;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        etTitle = findViewById(R.id.etTitle);
        etDescription = findViewById(R.id.etDescription);
        btnAdd = findViewById(R.id.btnAdd);

        databaseHelper = new DatabaseHelper(AddActivity.this);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = etTitle.getText().toString().trim();
                String description = etDescription.getText().toString().trim();
                if(!title.isEmpty() && !description.isEmpty()) {
                    databaseHelper.addNote(new Note(title, description));
                    etTitle.getText().clear();
                    etDescription.getText().clear();
                } else {
                    Toast.makeText(AddActivity.this, "Proszę wypełnić pola formularza", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}