package com.example.temp151223_4tp1_sqlite;

import com.example.temp151223_4tp1_sqlite.database.DatabaseHelper;
import com.example.temp151223_4tp1_sqlite.model.Note;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TextView tvMsg;
    private FloatingActionButton floatingActionButton;
    private List<Note> notes = new ArrayList<>();
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        tvMsg = findViewById(R.id.tvMsg);
        floatingActionButton = findViewById(R.id.floatingActionButton);
        databaseHelper = new DatabaseHelper(MainActivity.this);

        storeNotesInList();

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });
    }

    private void storeNotesInList() {
        Cursor cursor = databaseHelper.getNotes();
        if(cursor.getCount() == 0) {
            tvMsg.setVisibility(View.VISIBLE);
        } else {
            tvMsg.setVisibility(View.GONE);
            while(cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String description = cursor.getString(2);
                long createdDate = cursor.getLong(3);
                Note note = new Note(id, title, description, createdDate);
                notes.add(note);
            }
        }

        Log.d("my_log", "storeNotesInList: " + notes.get(0).getTitle());
    }
}