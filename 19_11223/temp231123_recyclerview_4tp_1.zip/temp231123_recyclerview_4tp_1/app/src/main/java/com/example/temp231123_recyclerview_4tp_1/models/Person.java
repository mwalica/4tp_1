package com.example.temp231123_recyclerview_4tp_1.models;

import java.util.Random;

public class Person {
    private String name;
    private int age;
    private String imgUrl;


    public Person(String name, int age) {
        this.name = name;
        this.age = age;
        this.imgUrl = "https://randomuser.me/api/portraits/men/"+ (new Random().nextInt(71) + 10) +".jpg";
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getImgUrl() {
        return imgUrl;
    }
}
