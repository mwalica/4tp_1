package com.example.temp231123_recyclerview_4tp_1.adapter;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.temp231123_recyclerview_4tp_1.R;
import com.example.temp231123_recyclerview_4tp_1.models.Person;
import com.google.android.material.imageview.ShapeableImageView;

public class PersonViewHolder extends RecyclerView.ViewHolder {

    private TextView tvName, tvAge;
    private ShapeableImageView ivPhoto;

    public PersonViewHolder(View itemView) {
        super(itemView);
        tvName = itemView.findViewById(R.id.tvName);
        tvAge = itemView.findViewById(R.id.tvAge);
        ivPhoto = itemView.findViewById(R.id.ivPhoto);
    }

    public void bind(Person person) {
        tvName.setText(person.getName());
        tvAge.setText(person.getAge() + " lat");
        ivPhoto.setImageResource(R.drawable.sample);
    }
}
