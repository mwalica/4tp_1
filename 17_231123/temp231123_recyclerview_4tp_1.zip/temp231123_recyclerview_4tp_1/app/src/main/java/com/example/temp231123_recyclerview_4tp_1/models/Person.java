package com.example.temp231123_recyclerview_4tp_1.models;

public class Person {
    private String name;
    private int age;
    //private String imgUrl;


    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
