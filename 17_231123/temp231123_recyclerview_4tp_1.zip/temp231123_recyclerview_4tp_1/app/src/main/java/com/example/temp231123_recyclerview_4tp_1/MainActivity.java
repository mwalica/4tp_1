package com.example.temp231123_recyclerview_4tp_1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.temp231123_recyclerview_4tp_1.adapter.PersonsAdapter;
import com.example.temp231123_recyclerview_4tp_1.models.Person;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Person> persons = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        persons.add(new Person("Jan", 23));
        persons.add(new Person("Karol", 21));
        persons.add(new Person("Dominik", 27));
        persons.add(new Person("Gustaw", 28));
        persons.add(new Person("Jan", 23));
        persons.add(new Person("Karol", 21));
        persons.add(new Person("Dominik", 27));
        persons.add(new Person("Gustaw", 28));
        persons.add(new Person("Jan", 23));
        persons.add(new Person("Karol", 21));
        persons.add(new Person("Dominik", 27));
        persons.add(new Person("Gustaw", 28));

        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        PersonsAdapter personsAdapter = new PersonsAdapter(persons);
        recyclerView.setAdapter(personsAdapter);
    }
}