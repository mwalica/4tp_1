package com.example.temp261023_4tp1_custom_appbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;

public class SecondActivity extends AppCompatActivity {
    private MaterialToolbar materialToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        materialToolbar = findViewById(R.id.topAppBar2);

        materialToolbar.setTitle("Druga aktywność");
        materialToolbar.setTitleCentered(true);

        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        materialToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if(item.getItemId() == R.id.imFirst) {
                   finish();
                } else if(item.getItemId() == R.id.imSecond){
                    Toast.makeText(SecondActivity.this, "Jestem w aktywności 12", Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
    }
}