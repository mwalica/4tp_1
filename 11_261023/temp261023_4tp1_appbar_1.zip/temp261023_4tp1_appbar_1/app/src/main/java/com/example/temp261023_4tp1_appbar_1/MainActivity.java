package com.example.temp261023_4tp1_appbar_1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_bar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.imSettings) {
            Toast.makeText(this, "Ustawienia", Toast.LENGTH_SHORT).show();
        } else if(item.getItemId() == R.id.imEdit) {
            Toast.makeText(this, "Edycja", Toast.LENGTH_SHORT).show();
        } else if(item.getItemId() == R.id.imClose) {
            finish();
        }
        return true;
    }
}