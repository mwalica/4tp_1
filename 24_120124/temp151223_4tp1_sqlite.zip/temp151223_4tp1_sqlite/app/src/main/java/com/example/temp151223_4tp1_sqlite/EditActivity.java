package com.example.temp151223_4tp1_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.temp151223_4tp1_sqlite.database.DatabaseHelper;
import com.example.temp151223_4tp1_sqlite.model.Note;

public class EditActivity extends AppCompatActivity {

    private EditText etEditTitle, etEditDescription;
    private Button btnEdit;
    private DatabaseHelper databaseHelper;
    private String title, description;
    private int id;
    private long createDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        etEditTitle = findViewById(R.id.etEditTitle);
        etEditDescription = findViewById(R.id.etEditDescription);
        btnEdit = findViewById(R.id.btnEdit);

        databaseHelper = new DatabaseHelper(EditActivity.this);

        if(getIntent().hasExtra(MainActivity.NOTE_OBJ)) {
            Note note = (Note) getIntent().getSerializableExtra(MainActivity.NOTE_OBJ);
            title = note.getTitle();
            description = note.getDescription();
            id = note.getId();
            createDate = note.getCreatedDate();
            etEditTitle.setText(title);
            etEditDescription.setText(description);
        }

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                title = etEditTitle.getText().toString().trim();
                description = etEditDescription.getText().toString().trim();
                if(!title.isEmpty() && !description.isEmpty()) {
                    databaseHelper.editeNote(new Note(id, title, description, createDate));
                    setResult(RESULT_OK);
                    finish();
                }
            }
        });


    }
}