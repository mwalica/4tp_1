package com.example.temp290224_4tp_1_intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.example.temp290224_4tp_1_intent.model.User;

public class MainActivity extends AppCompatActivity {

    public static final String NAME_KEY = "name";
    public static final String USER_KEY = "user_obj";
    private Button btnSend, btnText, btnEmail, btnWeb, btnDial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSend = findViewById(R.id.btnSend);
        btnText = findViewById(R.id.btnText);
        btnEmail = findViewById(R.id.btnEmail);
        btnWeb = findViewById(R.id.btnWeb);
        btnDial = findViewById(R.id.btnDial);

        btnSend.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//            intent.putExtra(NAME_KEY, "Adam");
            intent.putExtra(USER_KEY, new User("Anna"));
            startActivity(intent);
        });

        btnText.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, "Hello Android");
            try {
                startActivity(Intent.createChooser(intent, "Wybierz aplikację..."));
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "Error: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }

        });

        btnEmail.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"mwalica@wp.pl", "marek.walica@szybinski.cieszyn.pl"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "temat wiadomości email");
            intent.putExtra(Intent.EXTRA_TEXT, "Hello Android - treść wiadomości");
            try {
                startActivity(intent);
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "Error: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        btnWeb.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://onet.pl"));
            try {
                startActivity(intent);
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "Error: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        btnDial.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:600100200"));
            try {
                startActivity(intent);
            } catch(ActivityNotFoundException e) {
                Toast.makeText(this, "Error: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }
}