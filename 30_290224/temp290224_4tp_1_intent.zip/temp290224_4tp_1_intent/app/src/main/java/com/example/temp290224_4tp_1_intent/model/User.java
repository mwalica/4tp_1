package com.example.temp290224_4tp_1_intent.model;

import java.io.Serializable;
import java.util.Random;

public class User implements Serializable {
    private String name;
    private int age;

    public User(String name) {
        this.name = name;
        this.age = new Random().nextInt(90) + 1;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
