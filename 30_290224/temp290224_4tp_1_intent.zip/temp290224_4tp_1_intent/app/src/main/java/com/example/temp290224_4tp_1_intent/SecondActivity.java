package com.example.temp290224_4tp_1_intent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.temp290224_4tp_1_intent.model.User;

public class SecondActivity extends AppCompatActivity {

    private TextView tvResult;
    private Button btnBack;

    private String name = "";
    private int age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvResult = findViewById(R.id.tvResult);
        btnBack = findViewById(R.id.btnBack);

        if(getIntent().hasExtra(MainActivity.USER_KEY)) {
//            name = getIntent().getStringExtra(MainActivity.NAME_KEY);
            User user = (User) getIntent().getSerializableExtra(MainActivity.USER_KEY);
            name = user.getName();
            age = user.getAge();
            tvResult.setText(name + " " + age);
        }

        btnBack.setOnClickListener(view -> {
            finish();
        });
    }
}