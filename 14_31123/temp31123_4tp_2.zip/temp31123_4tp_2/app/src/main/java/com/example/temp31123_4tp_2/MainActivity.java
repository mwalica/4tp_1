package com.example.temp31123_4tp_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText etName;
    private ListView listView;
    private Button btnAdd, btnSort;
    private List<String> names = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        listView = findViewById(R.id.listView);
        btnAdd = findViewById(R.id.btnAdd);
        btnSort = findViewById(R.id.btnSort);

        names.add("Karol");

        adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, names);
        listView.setAdapter(adapter);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etName.getText().toString().trim();
                if(!name.isEmpty()) {
                    names.add(name);
                    adapter.notifyDataSetChanged();
                    etName.getText().clear();
                } else {
                    Snackbar.make(view, "Proszę wpisać imię", Snackbar.LENGTH_SHORT).show();
                }
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                new MaterialAlertDialogBuilder(MainActivity.this)
                        .setMessage("Czy usunąć element listy?")
                        .setPositiveButton("Tak", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                names.remove(names.get(position));
                                adapter.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("Nie", null)
                        .show();
            }
        });

        btnSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Collections.sort(names);
                Log.e("my_log", "onClick: " + names);
                adapter.notifyDataSetChanged();
            }
        });
    }
}